The tree classic "language modeling for IR" papers:
- Ponte and Croft, A language modeling approach to information retrieval
- Hiemstra and Kraaij, Twenty-One at TREC-7
- Miller et al, BBN at TREC7: Using Hidden Markov Models for Information Retrieval
