Additional material:
- Balog et al, SIGIR 2008 
- Kraaij et al, SIGIR 2002 
- Song and Croft, CIKM 1999 
- Weerkamp and de Rijke, ACL 2008
