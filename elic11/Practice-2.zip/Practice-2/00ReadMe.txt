Additional material: topics, qrels, trec_eval

* Topics

The original topics which were used during the CLEF 2006 
adhoc track can be found below.

For the course, we have preprocessed this file to generate 
a TREC Text compatible file, using a simple Perl script.

- The original topics: ENtopicsC301-C325.txt

Lemur
- Script used to transform to TREC Web format: makeLemurQuery.pl.txt
- The original topics in TREC Web format: ENtopicsC301-C325_trecweb.txt
- Parameter file for ParseToFile: parse_params
- The original topics in Lemur-compatible (LDF) format: ENtopicsC301-C325_lemur.txt

Indri
- Script used to transform to Indri format: makeIndriQuery.pl.txt
- The original topics in Indri format: ENtopicsC301-C325_indri.txt 

* Qrels
- AH-ENGLISH-CLEF2006.txt

* trec_eval
- A zipfile containing the program can be: trec_eval-8.0.zip
- A pre-compiled version for Windows: trec_eval-7.3.exe
